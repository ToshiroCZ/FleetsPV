from extensions import db
from models import Vehicle

class VehicleRepository:
    """Repository for managing Vehicle data."""

    @staticmethod
    def get_all(sort_by='id', order='asc'):
        query = Vehicle.query
        if sort_by in ['id', 'year']:
            if order == 'asc':
                query = query.order_by(db.asc(getattr(Vehicle, sort_by)))
            else:
                query = query.order_by(db.desc(getattr(Vehicle, sort_by)))
        return query.all()

    @staticmethod
    def get_by_id(vehicle_id):
        return Vehicle.query.get(vehicle_id)

    @staticmethod
    def add(vehicle):
        db.session.add(vehicle)
        db.session.commit()

    @staticmethod
    def update():
        db.session.commit()

    @staticmethod
    def delete(vehicle):
        db.session.delete(vehicle)
        db.session.commit()
