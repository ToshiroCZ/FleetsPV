from extensions import db
from models import User

class UserRepository:
    """Repository for managing user data."""

    @staticmethod
    def get_by_id(user_id):
        """Get a user by ID."""
        return User.query.get(user_id)

    @staticmethod
    def get_by_username(username):
        """Get a user by username."""
        return User.query.filter_by(username=username).first()

    @staticmethod
    def add(user):
        """Add a new user."""
        db.session.add(user)
        db.session.commit()

    @staticmethod
    def delete(user):
        """Delete a user."""
        db.session.delete(user)
        db.session.commit()

    @staticmethod
    def update():
        """Update user data."""
        db.session.commit()
