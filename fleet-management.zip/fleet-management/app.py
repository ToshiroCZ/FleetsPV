import os
import json
from flask import Flask, render_template, redirect, url_for, flash, request
from extensions import db, login_manager, bcrypt
from models import User, Vehicle, Car, Reservation, Payment, Customer
from forms import RegistrationForm, LoginForm, VehicleForm, UpdateProfileForm
from repositories.vehicle_repository import VehicleRepository
from repositories.user_repository import UserRepository
from flask_login import login_user, login_required, logout_user, current_user

# Inicializace Flask aplikace
app = Flask(__name__)

# Načtení konfigurace z JSON souboru
env = os.getenv('FLASK_ENV', 'development')  # Výchozí prostředí je "development"
try:
    with open('config.json') as config_file:
        configs = json.load(config_file)
        app_config = configs.get(env, {})
        # Kontrola potřebných klíčů v konfiguraci
        required_keys = ['SECRET_KEY', 'SQLALCHEMY_DATABASE_URI', 'SQLALCHEMY_TRACK_MODIFICATIONS']
        for key in required_keys:
            if key not in app_config:
                raise KeyError(f"Missing required configuration key: {key}")
        app.config.update(app_config)
except FileNotFoundError:
    raise RuntimeError("Config file 'config.json' not found. Please create it.")
except KeyError as e:
    raise RuntimeError(f"Configuration error: {e}")
except json.JSONDecodeError:
    raise RuntimeError("Config file 'config.json' is not a valid JSON file.")

# Inicializace rozšíření
try:
    db.init_app(app)
except Exception as e:
    raise RuntimeError(f"Database initialization failed: {e}")
login_manager.init_app(app)
login_manager.login_view = 'login'

# Načtení uživatele pro Flask-Login
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Kontrola rolí uživatele
@app.route('/admin', methods=['GET'])
@login_required
def admin_panel():
    if not current_user.is_admin:
        flash('Access denied.', 'danger')
        return redirect(url_for('home'))
    return render_template('admin.html')

# Hlavní stránka
@app.route('/', methods=['GET'])
def home():
    return render_template('home.html')

# Registrační endpoint
# Kontrola pro jistotu
@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegistrationForm()
    if form.validate_on_submit():
        # Kontrola duplicity uživatelského jména
        existing_user = UserRepository.get_by_username(form.username.data)
        if existing_user:
            flash('Username already exists. Please choose a different one.', 'danger')
            return redirect(url_for('register'))

        # Ověření složitosti hesla
        password = form.password.data
        if len(password) < 8 or not any(char.isdigit() for char in password):
            flash('Password must be at least 8 characters long and contain at least one number.', 'danger')
            return redirect(url_for('register'))

        # Vytvoření uživatele
        hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
        new_user = User(username=form.username.data, password=hashed_password)
        try:
            UserRepository.add(new_user)
            flash('Registration successful! You can now log in.', 'success')
            return redirect(url_for('login'))
        except Exception as e:
            flash(f"Error creating user: {e}", 'danger')
            return redirect(url_for('register'))
    return render_template('register.html', form=form)

# Přihlašovací endpoint
@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = UserRepository.get_by_username(form.username.data)
        if user and bcrypt.check_password_hash(user.password, form.password.data):
            login_user(user)
            flash('Logged in successfully!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid username or password', 'danger')
    return render_template('login.html', form=form)

# Odhlašovací endpoint
@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('login'))

# Profil uživatele
@app.route('/profile')
@login_required
def profile():
    return render_template('profile.html', user=current_user)

# Aktualizace profilu
@app.route('/profile/edit', methods=['GET', 'POST'])
@login_required
def edit_profile():
    form = UpdateProfileForm(obj=current_user)

    if form.validate_on_submit():
        current_user.username = form.username.data

        # Pokud uživatel zadal nové heslo, zašifruj ho a aktualizuj
        if form.password.data:
            hashed_password = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
            current_user.password = hashed_password

        db.session.commit()
        flash('Your profile has been updated successfully!', 'success')
        return redirect(url_for('profile'))

    return render_template('edit_profile.html', form=form)

# Smazání účtu
@app.route('/profile/delete', methods=['POST'])
@login_required
def delete_account():
    user_id = current_user.id
    logout_user()

    user = User.query.get(user_id)
    db.session.delete(user)
    db.session.commit()

    flash('Your account has been deleted successfully!', 'info')
    return redirect(url_for('home'))

# Menu
@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html')

# Generování reportu
@app.route('/report')
@login_required
def report():
    try:
        report_data = db.session.execute("""
            EXEC GenerateSummaryReport
        """).fetchall()
        return render_template('report.html', report=report_data)
    except Exception as e:
        flash(f"Error generating report: {e}", 'danger')
        return redirect(url_for('home'))


# Přidání vozidel
@app.route('/add-vehicle', methods=['GET', 'POST'])
@login_required
def add_vehicle():
    form = VehicleForm()
    if form.validate_on_submit():
        if form.year.data < 1886 or form.year.data > 2050:  # Validace roku (první auto bylo v roce 1886)
            flash('Year must be between 1886 and 2050.', 'danger')
            return redirect(url_for('add_vehicle'))

        # Přidání vozidla do databáze
        new_vehicle = Vehicle(
            brand=form.brand.data.strip(),
            model=form.model.data.strip(),
            year=form.year.data
        )
        try:
            VehicleRepository.add(new_vehicle)
            flash('Vehicle added successfully!', 'success')
            return redirect(url_for('view_vehicles'))
        except Exception as e:
            flash(f"Error adding vehicle: {e}", 'danger')
            return redirect(url_for('add_vehicle'))
    return render_template('add_vehicle.html', form=form)

# Úprava vozidel
@app.route('/edit-vehicle/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_vehicle(id):
    vehicle = VehicleRepository.get_by_id(id)
    if not vehicle:
        flash('Vehicle not found!', 'danger')
        return redirect(url_for('view_vehicles'))

    form = VehicleForm(obj=vehicle)
    if form.validate_on_submit():
        try:
            vehicle.brand = form.brand.data.strip()
            vehicle.model = form.model.data.strip()
            vehicle.year = form.year.data
            VehicleRepository.update()
            flash('Vehicle updated successfully!', 'success')
            return redirect(url_for('view_vehicles'))
        except Exception as e:
            flash(f"Error updating vehicle: {e}", 'danger')
    return render_template('edit_vehicle.html', form=form, vehicle=vehicle)

# Rezervace
@app.route('/add-customer-reservation', methods=['GET', 'POST'])
@login_required
def add_customer_reservation():
    cars = Car.query.all()  # Získání seznamu všech aut
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        phone = request.form.get('phone')
        license_number = request.form['license_number']
        car_id = request.form['car_id']
        start_date = request.form['start_date']
        end_date = request.form['end_date']
        total_amount = request.form['total_amount']
        try:
            # Spuštění transakce
            db.session.begin()
            new_customer = Customer(
                Name=name.strip(),
                Email=email.strip(),
                Phone=phone.strip() if phone else None,
                DriverLicenseNumber=license_number.strip()
            )
            db.session.add(new_customer)
            db.session.flush()  # Získání CustomerID

            new_reservation = Reservation(
                CustomerID=new_customer.CustomerID,
                CarID=int(car_id),
                StartDate=start_date,
                EndDate=end_date,
                TotalAmount=float(total_amount)
            )
            db.session.add(new_reservation)
            db.session.commit()  # Dokončení transakce

            flash('Customer and reservation added successfully!', 'success')
        except Exception as e:
            db.session.rollback()
            flash(f"Error: {e}", 'danger')

    return render_template('add_customer_reservation.html', cars=cars)


# Spravování vozidel
@app.route('/cars', methods=['GET', 'POST'])
@login_required
def manage_cars():
    if request.method == 'POST':
        model = request.form['model']
        brand = request.form['brand']
        license_plate = request.form['license_plate']
        daily_rate = request.form['daily_rate']
        try:
            new_car = Car(Model=model, Brand=brand, LicensePlate=license_plate, DailyRate=daily_rate)
            db.session.add(new_car)
            db.session.commit()
            flash('Car added successfully!', 'success')
        except Exception as e:
            db.session.rollback()
            flash(f"Error adding car: {e}", 'danger')
    cars = Car.query.order_by(Car.Brand).all()
    return render_template('cars.html', cars=cars)

# Smazání vozidel
@app.route('/delete-vehicle/<int:id>', methods=['POST'])
@login_required
def delete_vehicle(id):
    vehicle = VehicleRepository.get_by_id(id)
    if vehicle:
        VehicleRepository.delete(vehicle)
        flash('Vehicle deleted successfully!', 'info')
    else:
        flash('Vehicle not found!', 'danger')
    return redirect(url_for('view_vehicles'))

# Výpis vozidel
@app.route('/vehicles')
@login_required
def view_vehicles():
    sort_by = request.args.get('sort_by', 'id')
    order = request.args.get('order', 'asc')
    vehicles = VehicleRepository.get_all(sort_by=sort_by, order=order)
    return render_template('vehicles.html', vehicles=vehicles, sort_by=sort_by, order=order)

# Error handling
@app.errorhandler(404)
def not_found_error(error):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()  # Vrácení transakcí, které mohly selhat
    return render_template('500.html'), 500

@app.errorhandler(Exception)
def handle_unexpected_error(error):
    app.logger.error(f"Unexpected error: {error}")
    flash('An unexpected error occurred. Please try again later.', 'danger')
    return render_template('500.html'), 500

if __name__ == '__main__':
    with app.app_context():
        db.create_all()  # Vytvoření tabulek při prvním spuštění
    app.run(debug=app.config['DEBUG'])
