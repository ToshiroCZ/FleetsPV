from extensions import db
from flask_login import UserMixin


class User(db.Model, UserMixin):
    __tablename__ = 'Users'

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password = db.Column(db.String(128), nullable=False)


class Vehicle(db.Model):
    __tablename__ = 'Vehicles'

    id = db.Column(db.Integer, primary_key=True)
    brand = db.Column(db.String(50), nullable=False)
    model = db.Column(db.String(50), nullable=False)
    year = db.Column(db.Integer, nullable=False)

class Car(db.Model):
    __tablename__ = 'Car'
    CarID = db.Column(db.Integer, primary_key=True, autoincrement=True)
    Model = db.Column(db.String(100), nullable=False)
    Brand = db.Column(db.String(100), nullable=False)
    LicensePlate = db.Column(db.String(20), unique=True, nullable=False)
    DailyRate = db.Column(db.Float, nullable=False)

class Customer(db.Model):
    __tablename__ = 'Customer'
    CustomerID = db.Column(db.Integer, primary_key=True, autoincrement=True)
    Name = db.Column(db.String(100), nullable=False)
    Email = db.Column(db.String(100), unique=True, nullable=False)
    Phone = db.Column(db.String(15))
    DriverLicenseNumber = db.Column(db.String(20), unique=True, nullable=False)

class Employee(db.Model):
    __tablename__ = 'Employee'
    EmployeeID = db.Column(db.Integer, primary_key=True, autoincrement=True)
    Name = db.Column(db.String(100), nullable=False)
    ProvisionRate = db.Column(db.Float, nullable=False)

class Reservation(db.Model):
    __tablename__ = 'Reservation'
    ReservationID = db.Column(db.Integer, primary_key=True, autoincrement=True)
    CustomerID = db.Column(db.Integer, db.ForeignKey('Customer.CustomerID'), nullable=False)
    CarID = db.Column(db.Integer, db.ForeignKey('Car.CarID'), nullable=False)
    EmployeeID = db.Column(db.Integer, db.ForeignKey('Employee.EmployeeID'))
    StartDate = db.Column(db.Date, nullable=False)
    EndDate = db.Column(db.Date, nullable=False)
    AmountPayed = db.Column(db.Float, nullable=False, default=0.0)
    TotalAmount = db.Column(db.Float, nullable=False)

class Payment(db.Model):
    __tablename__ = 'Payment'
    PaymentID = db.Column(db.Integer, primary_key=True, autoincrement=True)
    ReservationID = db.Column(db.Integer, db.ForeignKey('Reservation.ReservationID'), nullable=False)
    PaymentDate = db.Column(db.Date, nullable=False)
    AmountPaid = db.Column(db.Float, nullable=False)
    IsComplete = db.Column(db.Boolean, default=False)
    PaymentMethod = db.Column(db.Enum('Credit Card', 'Cash', 'Bank Transfer'), nullable=False)